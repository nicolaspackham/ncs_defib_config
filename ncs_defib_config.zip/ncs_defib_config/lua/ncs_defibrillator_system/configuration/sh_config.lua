NCS_DEFIBRILLATOR.CONFIG.respawnTimer = 5 -- Amount of time to wait before respawning.

NCS_DEFIBRILLATOR.CONFIG.forceRespawn = true -- Default True, when false it stops the system from respawning for you

NCS_DEFIBRILLATOR.CONFIG.jobBlacklist = { -- Jobs that don't use the Defibrillator spawn system.
    --["Gun Dealer"] = true,
}

NCS_DEFIBRILLATOR.CONFIG.medicWhitelist = { -- Jobs that will be able to see the pings (leave empty for anyone with a defibrillator.)
    --["Citizen"] = true,
}

NCS_DEFIBRILLATOR.CONFIG.defibUsage = false -- Amount of times a Defibrillator that can be used before being destroyed.

NCS_DEFIBRILLATOR.CONFIG.medicRange = 2000

NCS_DEFIBRILLATOR.CONFIG.LANG = "en"