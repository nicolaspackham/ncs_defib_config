NCS_DEFIBRILLATOR.AddLang("en", {
    nearbyMedicsNotified = "NEARBY MEDICS NOTIFIED",
    noNearbyMedics = "NO MEDICS AVAILABLE",
    secondsRemaining = "(%s) Seconds Remaining",
})